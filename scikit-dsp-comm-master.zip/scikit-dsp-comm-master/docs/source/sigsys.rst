sigsys
======

.. automodule:: sk_dsp_comm.sigsys
		:members:
