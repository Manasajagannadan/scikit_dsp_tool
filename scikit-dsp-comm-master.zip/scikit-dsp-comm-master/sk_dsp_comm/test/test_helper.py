from unittest import TestCase
import numpy as np

class SKDSPCommTest(TestCase):

    def setUp(self):
        np.random.seed(100)